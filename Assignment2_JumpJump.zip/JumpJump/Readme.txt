AsteroidAttack! game
Assignment 2 
Sarbjot Singh 17190067
Sam Spark 18040422
159.261, Games Programming
